import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        "azul-oscuro": "#1A2F6C",
        blanco: "#FFFFFF",
        "gris-claro": "#D2D2D2",
        "gris-oscuro": "#3a3a3a",
        "verde-azulado": "#6CC3C9",
        "verde-claro": "#92C14F",
        "azul-intenso": "#1E4398",
        "verde-lineas": "#538D4A",
        "gris-texto": "#7A7A7A",
        "verde-azulado-claro": "rgba(108, 195, 201, 0.1)",
      },
      fontFamily: {
        montserrat: ["Montserrat", "sans-serif"],
        "open-sans": ["Open Sans", "sans-serif"],
      },
      animation: {
        "fade-in-up": "fadeInUp 1s ease-out forwards",
      },
      keyframes: {
        fadeInUp: {
          "0%": { opacity: "0", transform: "translateY(30px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
    },
  },
  plugins: [],
} satisfies Config;
