import { useEffect } from "react";
import Header from "./components/Header";
import About from "./components/About";
import Services from "./components/Services";
import Technology from "./components/Technology";
import Testimonials from "./components/Testimonials";
import Blog from "./components/Blog";
import Newsletter from "./components/Newsletter";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import WhatsAppFloat from "./components/WhatsAppFloat";
import Bubble from "./components/Bubble";

function App() {
  useEffect(() => {
    // Animaciones se manejan vía CSS
  }, []);

  return (
    <div className="font-sans text-azul-oscuro bg-white overflow-x-hidden">
      <Header />
      <About />
      <Services />
      <Technology />
      <Testimonials />
      <Blog />
      <Newsletter />
      <Contact />
      <Footer />
      <WhatsAppFloat />
      <Bubble position="top-right" size="lg" />
      <Bubble position="bottom-left" size="md" />
    </div>
  );
}

export default App;
