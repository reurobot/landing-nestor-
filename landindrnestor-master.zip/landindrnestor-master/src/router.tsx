import { createBrowserRouter } from "react-router-dom";
import App from "./App";
import BlogLayout from "./components/BlogLayout";
import Blog from "./components/Blog";
import BlogPostDetail from "./components/BlogPostDetail";
import AdminBlogForm from "./components/admin/AdminBlogForm";
import AdminLayout from "./components/admin/AdminLayout";
import ListBlogPosts from "./components/admin/ListBlogPosts";
import EditBlogPost from "./components/admin/EditBlogPost";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
  },
  {
    path: "/blog",
    element: <BlogLayout />,
    children: [
      {
        index: true,
        element: <Blog />,
      },
      {
        path: ":id",
        element: <BlogPostDetail />,
      },
    ],
  },
  {
    path: "/admin",
    element: <AdminLayout />,
    children: [
      {
        index: true, // /admin
        element: <ListBlogPosts />,
      },
      {
        path: "blogform",
        element: <AdminBlogForm />,
      },
      {
        path: "blog/:id",
        element: <EditBlogPost />,
      },
    ],
  },
]);
