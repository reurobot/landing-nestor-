import { db } from "./firebase";
import { collection, addDoc, Timestamp, setDoc, doc } from "firebase/firestore";
import type { BlogPost } from "../types/blog";

// interface BlogContentBlock {
//   id: string;
//   type: "title" | "subtitle" | "paragraph" | "image";
//   value: string;
// }

export const useSaveBlogPost = () => {
  const saveBlogPost = async (data: BlogPost) => {
    try {
      const postWithTimestamp = {
        ...data,
        createdAt: Timestamp.now(),
      };
      const docRef = await addDoc(
        collection(db, "blogPosts"),
        postWithTimestamp
      );
      return { success: true, id: docRef.id };
    } catch (error) {
      console.error("Error al guardar el blog post:", error);
      return { success: false, error };
    }
  };

  return { saveBlogPost };
};

export const useEditBlogPost = () => {
  const editBlogPost = async (data: BlogPost) => {
    try {
      if (!data.id) {
        return { success: false, error: new Error("ID no proporcionado") };
      }

      const postWithTimestamp = {
        ...data,
        updatedAt: Timestamp.now(),
      };

      const docRef = doc(db, "blogPosts", data.id);
      await setDoc(docRef, postWithTimestamp, { merge: true });
      return { success: true, id: data.id };
    } catch (error) {
      console.error("Error al guardar el blog post: ", error);
      return { success: false, error };
    }
  };

  return { editBlogPost };
};
