import { useEffect, useState } from "react";
import { doc, getDoc, collection, getDocs } from "firebase/firestore";
import { db } from "./firebase";
import type { BlogPost } from "../types/blog";

export const useFetchBlogPost = (id: string | undefined) => {
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPost = async () => {
      // early return
      if (!id) return;

      try {
        const docRef = doc(db, "blogPosts", id);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const data = docSnap.data() as BlogPost;
          setPost(data);
        } else {
          setError("No se encontro el post.");
        }
      } catch (err) {
        console.error("Error fetching post:", err);
        setError("Hubo un error al cargar el post.");
      } finally {
        setLoading(false);
      }
    };
    fetchPost();
  }, [id]);
  return { post, loading, error };
};

export const useFetchAllBlogPosts = () => {
  const [posts, setPosts] = useState<BlogPost[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "blogPosts"));
        const fetchedPosts: BlogPost[] = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...(doc.data() as Omit<BlogPost, "id">),
        }));
        setPosts(fetchedPosts);
      } catch (err) {
        console.error("Error fetching all posts: ", err);
        setError("Hubo un error al cargar los posts");
      } finally {
        setLoading(false);
      }
    };
    fetchPosts();
  }, []);
  return { posts, loading, error };
};
