import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyA9wgtOQeOmqOvvia6z0WttDvPrW6CNj6M",
  authDomain: "drborjasblog.firebaseapp.com",
  projectId: "drborjasblog",
  storageBucket: "drborjasblog.firebasestorage.app",
  messagingSenderId: "951445530886",
  appId: "1:951445530886:web:9761d98604ccea09061687",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
