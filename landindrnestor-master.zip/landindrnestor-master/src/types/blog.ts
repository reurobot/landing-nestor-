export type BlogContentBlock =
  | { id: string; type: "title"; value: string }
  | { id: string; type: "subtitle"; value: string }
  | { id: string; type: "paragraph"; value: string }
  | { id: string; type: "image"; value: string };

export interface BlogPost {
  id?: string;
  title: string;
  excerpt: string;
  date: string;
  author: string;
  image: string;
  category: string;
  content: BlogContentBlock[];
}
