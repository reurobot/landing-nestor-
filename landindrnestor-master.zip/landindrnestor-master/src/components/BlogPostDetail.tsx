import { useParams } from "react-router-dom";
import { FaCalendarAlt, FaUser } from "react-icons/fa";
import { useFetchBlogPost } from "../firebase/useFetchBlogPost";
import { useEffect } from "react";

const BlogPostDetail = () => {
  const { id } = useParams();
  const { post, loading, error } = useFetchBlogPost(id);
  useEffect(() => {
    if (!post) return;

    // Esperamos un pequeño momento para asegurar que el DOM esté listo
    setTimeout(() => {
      const el = document.getElementById("start");
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }, 0);
  }, [post]);
  if (loading) return <p> Cargando publicacion ...</p>;
  if (error) return <p>{error}</p>;
  if (!post) return <p>Publicacion no encontrada.</p>;

  return (
    <section
      id="start"
      className="py-20 bg-gradient-to-br from-gray-50 to-white"
    >
      <div className="max-w-5xl mx-auto px-8">
        <div className="mb-8 flex justify-center">
          <img
            src={post.image}
            alt={post.title}
            className="w-full max-h-[300px] object-contain rounded-lg "
          />
        </div>

        <div className="text-center mb-8">
          <h1 className="text-4xl font-extrabold text-[#1A2F6C] mb-4">
            {post.title}
          </h1>
          <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <FaCalendarAlt />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center gap-1">
              <FaUser />
              <span>{post.author}</span>
            </div>
          </div>
        </div>
        <div className="text-gray-700 leading-relaxed text-lg space-y-6">
          {post.content.map((block) => {
            switch (block.type) {
              case "title":
                return (
                  <h2 key={block.id} className="text-2xl font-bold">
                    {block.value}
                  </h2>
                );
              case "subtitle":
                return (
                  <h3
                    key={block.id}
                    className="text-xl font-semibold text-blue-300"
                  >
                    {block.value}
                  </h3>
                );
              case "paragraph":
                return <p key={block.id}>{block.value}</p>;
              case "image":
                return (
                  <img
                    key={block.id}
                    src={block.value}
                    alt="Contenido del blog"
                    className="w-full max-h-[400px] object-contain rounded-md"
                  />
                );
              default:
                return null;
            }
          })}
        </div>
      </div>
    </section>
  );
};

export default BlogPostDetail;
