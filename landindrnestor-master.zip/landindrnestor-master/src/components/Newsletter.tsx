import { useState } from "react";
import {
  FaEnvelope,
  FaCheckCircle,
  FaNewspaper,
  FaUserMd,
} from "react-icons/fa";

const Newsletter = () => {
  const [email, setEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsLoading(true);
      // Simular envío
      setTimeout(() => {
        setIsLoading(false);
        setIsSubscribed(true);
        setEmail("");
      }, 2000);
    }
  };

  const benefits = [
    {
      icon: <FaUserMd className="text-2xl text-[#6CC3C9]" />,
      title: "Consejos Médicos Exclusivos",
      description: "Recibe recomendaciones personalizadas del Dr. Borjas",
    },
    {
      icon: <FaNewspaper className="text-2xl text-[#92C14F]" />,
      title: "Últimas Investigaciones",
      description: "Mantente al día con avances en medicina de rehabilitación",
    },
    {
      icon: <FaCheckCircle className="text-2xl text-[#1A2F6C]" />,
      title: "Casos de Éxito",
      description: "Conoce historias inspiradoras de recuperación",
    },
  ];

  return (
    <section
      id="newsletter"
      className="py-20 bg-gradient-to-br from-[#1A2F6C] to-[#2A4A8C] relative overflow-hidden"
    >
      {/* Decorative background elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 bg-[#6CC3C9] rounded-full"></div>
        <div className="absolute bottom-20 right-20 w-32 h-32 bg-[#92C14F] rounded-full"></div>
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-white rounded-full"></div>
      </div>

      <div className="max-w-6xl mx-auto px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-extrabold text-white mb-6">
            Newsletter Médico
          </h2>
          <p className="text-xl text-white/90 max-w-3xl mx-auto leading-relaxed">
            Únete a más de 2,000 profesionales de la salud y pacientes que
            reciben contenido exclusivo sobre medicina de rehabilitación.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Benefits Section */}
          <div className="space-y-8">
            <h3 className="text-3xl font-bold text-white mb-8">
              ¿Qué recibirás?
            </h3>

            {benefits.map((benefit, index) => (
              <div
                key={index}
                className="flex items-start gap-4 bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/20 transition-all duration-300"
              >
                <div className="flex-shrink-0 p-3 bg-white rounded-lg">
                  {benefit.icon}
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-white mb-2">
                    {benefit.title}
                  </h4>
                  <p className="text-white/80">{benefit.description}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Subscription Form */}
          <div className="bg-white rounded-2xl p-8 shadow-2xl">
            {!isSubscribed ? (
              <>
                <div className="text-center mb-6">
                  <FaEnvelope className="text-5xl text-[#6CC3C9] mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-[#1A2F6C] mb-2">
                    Suscríbete Ahora
                  </h3>
                  <p className="text-gray-600">
                    Newsletter gratuito • Sin spam • Cancela cuando quieras
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label
                      htmlFor="email"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      Correo Electrónico
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#6CC3C9] focus:border-transparent transition-all duration-300"
                      placeholder="tu@email.com"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-[#6CC3C9] to-[#92C14F] text-white py-4 px-6 rounded-lg font-bold hover:from-[#5AB3B9] hover:to-[#82B13F] transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        Suscribiendo...
                      </div>
                    ) : (
                      "Suscribirme Gratis"
                    )}
                  </button>
                </form>

                <p className="text-xs text-gray-500 mt-4 text-center">
                  Al suscribirte, aceptas recibir emails del Dr. Néstor Borjas.
                  Puedes darte de baja en cualquier momento.
                </p>
              </>
            ) : (
              <div className="text-center py-8">
                <FaCheckCircle className="text-6xl text-[#92C14F] mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-[#1A2F6C] mb-2">
                  ¡Suscripción Exitosa!
                </h3>
                <p className="text-gray-600 mb-6">
                  Gracias por suscribirte. Pronto recibirás contenido exclusivo
                  sobre medicina de rehabilitación.
                </p>
                <button
                  onClick={() => setIsSubscribed(false)}
                  className="text-[#6CC3C9] hover:text-[#1A2F6C] font-semibold transition-colors duration-300"
                >
                  Volver al formulario
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 pt-16 border-t border-white/20">
          <div className="text-center">
            <div className="text-3xl font-bold text-[#6CC3C9] mb-2">2,000+</div>
            <div className="text-white/80">Suscriptores</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-[#92C14F] mb-2">95%</div>
            <div className="text-white/80">Satisfacción</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">2x</div>
            <div className="text-white/80">Por Mes</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-[#6CC3C9] mb-2">100%</div>
            <div className="text-white/80">Gratuito</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
