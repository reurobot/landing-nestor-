import Header from "./Header";
import Footer from "./Footer";
import { Outlet } from "react-router-dom";

const BlogLayout = () => (
  <>
    <Header />
    <main className="min-h-screen bg-white">
      <Outlet />
    </main>
    <Footer />
  </>
);

export default BlogLayout;
