import { FaWhatsapp } from "react-icons/fa";

const WhatsAppFloat = () => {
  return (
    <div className="fixed bottom-8 right-8 z-50">
      {/* Círculo pulsante de fondo */}
      <div className="absolute inset-0 bg-[#25D366] rounded-full animate-ping opacity-20"></div>
      <div className="absolute inset-0 bg-[#25D366] rounded-full animate-pulse opacity-30"></div>

      {/* Botón principal */}
      <a
        href="https://wa.me/584146744688?text=Hola%20Dr.%20Borjas,%20quisiera%20agendar%20una%20consulta"
        target="_blank"
        rel="noopener noreferrer"
        className="relative bg-[#25D366] text-white w-16 h-16 rounded-full flex items-center justify-center text-3xl shadow-lg shadow-[#25D366]/30 transition-all duration-400 hover:scale-110 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#25D366]/50"
      >
        <FaWhatsapp />
      </a>
    </div>
  );
};

export default WhatsAppFloat;
