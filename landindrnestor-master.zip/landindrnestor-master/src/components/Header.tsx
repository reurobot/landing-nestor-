import { FaCalendarCheck, FaBookMedical } from "react-icons/fa";
import Navigation from "./Navigation";

const Header = () => {
  return (
    <>
      <Navigation />
      <header
        id="inicio"
        className="min-h-screen flex items-center relative overflow-hidden px-8 bg-[url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')] bg-cover bg-center bg-no-repeat"
      >
        {/* Overlay de opacidad múltiple para mejor legibilidad */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#1A2F6C]/50 via-black/40 to-[#1A2F6C]/50"></div>
        <div className="absolute inset-0 bg-black/50"></div>

        <div className="relative z-10 max-w-6xl mx-auto w-full py-24">
          <div className="logo animate-fade-in-up">
            <span className="font-montserrat text-4xl md:text-7xl font-extrabold text-white drop-shadow-2xl [text-shadow:_2px_2px_4px_rgb(0_0_0_/_80%)]">
              Dr.{" "}
              <span className="text-[#6CC3C9] font-black drop-shadow-2xl">
                Néstor Borjas
              </span>
            </span>
            {/* Línea horizontal debajo del nombre para separación visual */}
            <div className="w-32 h-0.5 bg-gradient-to-r from-[#6CC3C9]/60 via-[#6CC3C9]/30 to-transparent mt-3 mb-6"></div>
          </div>

          <h1 className="text-4xl md:text-7xl font-extrabold text-white leading-tight max-w-4xl mb-6 animate-fade-in-up animation-delay-200 drop-shadow-2xl shadow-black/80 [text-shadow:_2px_2px_4px_rgb(0_0_0_/_80%)]">
            Medicina Física y Rehabilitación, resultados que transforman vida.
          </h1>
          <h2 className="text-[#86eff3] font-black text-4xl">
            Graduado en la Universidad de Buenos Aires
          </h2>

          <p className="pb-4 text-lg md:text-2xl text-white max-w-3xl font-normal leading-normal md:leading-loose tracking-wide animate-fade-in-up animation-delay-200 drop-shadow-xl [text-shadow:_2px_2px_4px_rgb(0_0_0_/_80%)]">
            (UBA) Buenos Aires, Argentina y en Salud Ocupacional en la
            Universidad Experimental de Guayana en Puerto Ordaz Venezuela,
          </p>

          <div className="animate-fade-in-up animation-delay-400 flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a
              href="#contacto"
              className="cta-button bg-[#92C14F] text-white px-6 py-3 rounded-full font-bold inline-flex items-center justify-center gap-2 transition-all duration-400 hover:-translate-y-1 shadow-2xl shadow-[#92C14F]/50 hover:shadow-2xl hover:shadow-[#92C14F]/70 hover:scale-105 backdrop-blur-sm border-2 border-[#92C14F] text-sm md:text-base whitespace-nowrap w-80"
            >
              <FaCalendarCheck className="animate-pulse flex-shrink-0" />
              <span>Agendar evaluación</span>
            </a>
            <a
              href="#servicios"
              className="cta-button bg-transparent text-white border-2 border-white px-6 py-3 rounded-full font-bold inline-flex items-center justify-center gap-2 transition-all duration-400 hover:bg-white/10 backdrop-blur-sm hover:-translate-y-1 text-sm md:text-base whitespace-nowrap w-80"
            >
              <FaBookMedical className="flex-shrink-0" />
              <span>Conocer tratamientos</span>
            </a>
          </div>
        </div>
      </header>
    </>
  );
};

export default Header;
