import {
  FaFacebook,
  FaInstagram,
  FaLinkedin,
  FaPhone,
  FaEnvelope,
  FaMapMarkerAlt,
} from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-azul-oscuro text-black py-12 px-8">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo y descripción */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <span className="font-montserrat text-2xl font-extrabold text-black">
                Dr.{" "}
                <span className="text-verde-azulado font-bold">
                  Néstor Borjas
                </span>
              </span>
              <div className="w-12 h-1 bg-verde-claro mt-2"></div>
            </div>
            <p className="text-gris-claro mb-6 leading-relaxed">
              Especialista en Medicina de Rehabilitación comprometido con
              brindar tratamientos integrales y personalizados para mejorar la
              calidad de vida de nuestros pacientes.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-gris-claro hover:text-verde-azulado transition-colors"
              >
                <FaFacebook className="text-xl" />
              </a>
              <a
                href="#"
                className="text-gris-claro hover:text-verde-azulado transition-colors"
              >
                <FaInstagram className="text-xl" />
              </a>
              <a
                href="#"
                className="text-gris-claro hover:text-verde-azulado transition-colors"
              >
                <FaLinkedin className="text-xl" />
              </a>
            </div>
          </div>

          {/* Enlaces rápidos */}
          <div>
            <h3 className="text-lg font-bold mb-6">Enlaces Rápidos</h3>
            <ul className="space-y-3">
              <li>
                <a
                  href="#about"
                  className="text-gris-claro hover:text-verde-azulado transition-colors"
                >
                  Sobre el Doctor
                </a>
              </li>
              <li>
                <a
                  href="#servicios"
                  className="text-gris-claro hover:text-verde-azulado transition-colors"
                >
                  Servicios
                </a>
              </li>
              <li>
                <a
                  href="#technology"
                  className="text-gris-claro hover:text-verde-azulado transition-colors"
                >
                  Tecnología
                </a>
              </li>
              <li>
                <a
                  href="#testimonials"
                  className="text-gris-claro hover:text-verde-azulado transition-colors"
                >
                  Testimonios
                </a>
              </li>
              <li>
                <a
                  href="#contacto"
                  className="text-gris-claro hover:text-verde-azulado transition-colors"
                >
                  Contacto
                </a>
              </li>
            </ul>
          </div>

          {/* Contacto */}
          <div>
            <h3 className="text-lg font-bold mb-6">Contacto</h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <FaPhone className="text-verde-claro mr-3" />
                <span className="text-gris-claro text-sm">
                  +52 (55) 1234-5678
                </span>
              </div>
              <div className="flex items-center">
                <FaEnvelope className="text-verde-claro mr-3" />
                <span className="text-gris-claro text-sm">
                  consultas@drborjas.com
                </span>
              </div>
              <div className="flex items-start">
                <FaMapMarkerAlt className="text-verde-claro mr-3 mt-1" />
                <span className="text-gris-claro text-sm">
                  Av. Insurgentes Sur 1234
                  <br />
                  Col. Del Valle, CDMX
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-azul-intenso mt-12 pt-8 text-center">
          <p className="text-gris-claro text-sm">
            © 2024 Dr. Néstor Borjas. Todos los derechos reservados. |
            <a href="#" className="text-verde-azulado hover:underline ml-1">
              Aviso de Privacidad
            </a>{" "}
            |
            <a href="#" className="text-verde-azulado hover:underline ml-1">
              Términos y Condiciones
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
