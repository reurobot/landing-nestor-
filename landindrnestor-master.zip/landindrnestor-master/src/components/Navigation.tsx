import { useState } from "react";
import { FaBars, FaTimes, FaStethoscope } from "react-icons/fa";

const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const menuItems = [
    { name: "Inicio", href: "/#inicio" },
    { name: "Acerca", href: "/#acerca" },
    { name: "Servicios", href: "/#servicios" },
    { name: "Tecnología", href: "/#tecnologia" },
    { name: "Testimonios", href: "/#testimonios" },
    { name: "Blog", href: "/#blog" },
    { name: "Newsletter", href: "/#newsletter" },
    { name: "Contacto", href: "/#contacto" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#00187f]/80 backdrop-blur-md border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <FaStethoscope className="text-[#6CC3C9] text-2xl" />
            <span className="font-montserrat text-white font-bold text-lg">
              Dr. Néstor Borjas
            </span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {menuItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-white hover:text-[#6CC3C9] transition-colors duration-300 font-medium tracking-wide"
              >
                {item.name}
              </a>
            ))}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="text-white hover:text-[#6CC3C9] transition-colors duration-300"
            >
              {isMenuOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-[#00187f]/90 backdrop-blur-lg rounded-lg mt-2">
              {menuItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="block px-3 py-2 text-white hover:text-[#6CC3C9] hover:bg-white/10 rounded-md transition-all duration-300 font-medium"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;
