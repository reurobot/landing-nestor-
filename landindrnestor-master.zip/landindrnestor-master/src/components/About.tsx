import { FaGraduationCap, FaHeartbeat, FaCertificate } from "react-icons/fa";
import { useState } from "react";
import drImg from "../assets/dr.jpeg";

const About = () => {
  // Permitir múltiples secciones abiertas
  const [openSections, setOpenSections] = useState<string[]>([
    "formacion",
    "trayectoria",
  ]);
  const toggleSection = (section: string) => {
    setOpenSections((prev) =>
      prev.includes(section)
        ? prev.filter((s) => s !== section)
        : [...prev, section]
    );
  };

  return (
    <section id="acerca" className="py-12 px-4 bg-white">
      <div className="max-w-3xl mx-auto">
        {/* Título y misión */}
        <div className="flex flex-col items-center mb-8">
          <img
            src={drImg}
            alt="Dr. Néstor Borjas"
            className="rounded-full shadow-lg w-64 h-64 object-cover mb-4 border-4 border-verde-azulado"
          />
          <h2 className="text-3xl font-bold text-[#000080] mb-2 font-montserrat text-center">
            Sobre el Dr. Néstor Borjas
          </h2>
          <p className="text-base text-gris-texto max-w-xl text-center mb-2">
            Más de 37 años ayudando a pacientes a recuperar su calidad de vida
          </p>
          <div className="bg-gradient-to-r from-verde-azulado-claro to-white border-l-4 border-verde-azulado rounded-lg p-3 mt-2 shadow">
            <p className="text-azul-oscuro font-medium leading-relaxed text-sm">
              Mi misión es ayudar a cada paciente a alcanzar su máximo potencial
              funcional, combinando lo mejor de la medicina moderna con un
              enfoque humano y personalizado.
            </p>
          </div>
        </div>

        {/* Card principal con acordeones */}
        <div className="bg-white rounded-xl shadow-lg p-6 flex flex-col gap-4">
          {/* Formación Profesional */}
          <div>
            <button
              className="w-full text-left font-bold text-[#000080] py-2 focus:outline-none flex items-center justify-between"
              onClick={() => toggleSection("formacion")}
            >
              Formación Profesional
              <span className="relative w-10 h-10 flex items-center justify-center">
                {!openSections.includes("formacion") && (
                  <span className="absolute inset-0 rounded-full bg-verde-azulado opacity-30 animate-ping"></span>
                )}
                {!openSections.includes("formacion") && (
                  <span className="absolute inset-0 rounded-full bg-verde-azulado opacity-40 animate-pulse"></span>
                )}
                <span
                  className={
                    openSections.includes("formacion")
                      ? "text-verde-azulado text-2xl z-10"
                      : "text-verde-azulado font-bold text-2xl z-10"
                  }
                >
                  {openSections.includes("formacion") ? "-" : "+"}
                </span>
              </span>
            </button>
            {openSections.includes("formacion") && (
              <div className="pl-2 text-sm text-gris-texto">
                El Dr. Néstor Borjas es médico cirujano, por mas de 37 años,
                Universidad del Zulia, especialista en medicina física y
                rehabilitación en el Instituto Nacional de Rehabiltacion y
                Psicofisica (INAREP,) desde hace más de 33 años en Buenos Aires
                Argentina Especialista en Salud Ocupacional en la Universidad
                Experimental de Guayana, la UNEG
              </div>
            )}
          </div>

          {/* Trayectoria Académica */}
          <div>
            <button
              className="w-full text-left font-bold text-[#000080] py-2 focus:outline-none flex items-center justify-between"
              onClick={() => toggleSection("trayectoria")}
            >
              Trayectoria Académica
              <span className="relative w-10 h-10 flex items-center justify-center">
                {!openSections.includes("trayectoria") && (
                  <span className="absolute inset-0 rounded-full bg-verde-azulado opacity-30 animate-ping"></span>
                )}
                {!openSections.includes("trayectoria") && (
                  <span className="absolute inset-0 rounded-full bg-verde-azulado opacity-40 animate-pulse"></span>
                )}
                <span
                  className={
                    openSections.includes("trayectoria")
                      ? "text-verde-azulado text-2xl z-10"
                      : "text-verde-azulado font-bold text-2xl z-10"
                  }
                >
                  {openSections.includes("trayectoria") ? "-" : "+"}
                </span>
              </span>
            </button>
            {openSections.includes("trayectoria") && (
              <div className="pl-2 space-y-2 mt-2">
                {/* ...existing code... */}
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaGraduationCap className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Médico Cirujano
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - Universidad Nacional Autónoma de México
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaHeartbeat className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Especialidad en Fisiatría
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - Instituto Nacional de Rehabilitación
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaCertificate className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Diplomado en Dolor Crónico
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - Universidad de Barcelona
                    </span>
                  </div>
                </div>
                {/* Nuevos puntos agregados */}
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaCertificate className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Fellow en Neuro rehabilitación
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - Buenos Aires, Argentina
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaHeartbeat className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Fellow en Rehabilitación Cardiorespiratoria
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - Hospital Italiano, Buenos Aires, Argentina
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaHeartbeat className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Fellow en Rehabilitación Deportiva
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - Estadio de River, Buenos Aires, Argentina
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaCertificate className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Fellow en Patología de Columna Vertebral Urológico
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - San Román, Caracas
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaCertificate className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Fellow en Medicina del Dolor y en Cuidados Paliativos,
                      Rehabilitación Oncológica
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - Hospital Padre Machado, Caracas, Venezuela
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaGraduationCap className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Participante como expositor y asistente en diferentes
                      conferencias, nacional e internacionalmente
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Sociedades */}
          <div>
            <button
              className="w-full text-left font-bold text-[#000080] py-2 focus:outline-none flex items-center justify-between"
              onClick={() => toggleSection("sociedades")}
            >
              Sociedades a las que Pertenece
              <span className="relative w-10 h-10 flex items-center justify-center">
                {!openSections.includes("sociedades") && (
                  <span className="absolute inset-0 rounded-full bg-verde-azulado opacity-30 animate-ping"></span>
                )}
                {!openSections.includes("sociedades") && (
                  <span className="absolute inset-0 rounded-full bg-verde-azulado opacity-40 animate-pulse"></span>
                )}
                <span
                  className={
                    openSections.includes("sociedades")
                      ? "text-verde-azulado text-2xl z-10"
                      : "text-verde-azulado font-bold text-2xl z-10"
                  }
                >
                  {openSections.includes("sociedades") ? "-" : "+"}
                </span>
              </span>
            </button>
            {openSections.includes("sociedades") && (
              <div className="pl-2 space-y-2 mt-2">
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaCertificate className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Sociedad Venezolana de Medicina Física y Rehabilitación y
                      Capítulo Falcón Zulia de la Misma Sociedad
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaCertificate className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Sociedad Argentina de Medicina del Trabajo
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Docencia */}
          <div>
            <button
              className="w-full text-left font-bold text-[#000080] py-2 focus:outline-none flex items-center justify-between"
              onClick={() => toggleSection("docencia")}
            >
              Docencia y Formación Académica
              <span className="relative w-10 h-10 flex items-center justify-center">
                {!openSections.includes("docencia") && (
                  <span className="absolute inset-0 rounded-full bg-verde-azulado opacity-30 animate-ping"></span>
                )}
                {!openSections.includes("docencia") && (
                  <span className="absolute inset-0 rounded-full bg-verde-azulado opacity-40 animate-pulse"></span>
                )}
                <span
                  className={
                    openSections.includes("docencia")
                      ? "text-verde-azulado text-2xl z-10"
                      : "text-verde-azulado font-bold text-2xl z-10"
                  }
                >
                  {openSections.includes("docencia") ? "-" : "+"}
                </span>
              </span>
            </button>
            {openSections.includes("docencia") && (
              <div className="pl-2 space-y-2 mt-2">
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaGraduationCap className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Magíster en Docencia Universitaria
                    </span>
                    <span className="text-gris-texto">
                      {" "}
                      - Universidad Experimental Rafael María Baralt
                    </span>
                  </div>
                </div>
                <div className="flex items-center">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center mr-2 flex-shrink-0"
                    style={{ backgroundColor: "#6cc3c9" }}
                  >
                    <FaGraduationCap className="text-white text-xs" />
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-azul-oscuro">
                      Docente Universitario nacional e internacionalmente de
                      grado y posgrado
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
