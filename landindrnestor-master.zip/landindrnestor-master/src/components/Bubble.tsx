interface BubbleProps {
  position?: "top-right" | "bottom-left" | "top-left" | "bottom-right";
  size?: "sm" | "md" | "lg" | "xl";
}

const Bubble = ({ position = "top-right", size = "md" }: BubbleProps) => {
  const sizeClasses = {
    sm: "w-32 h-32",
    md: "w-48 h-48",
    lg: "w-64 h-64",
    xl: "w-80 h-80",
  };

  const positionClasses = {
    "top-right": "top-[-50px] right-[-50px]",
    "bottom-left": "bottom-[-25px] left-[-25px]",
    "top-left": "top-[-50px] left-[-50px]",
    "bottom-right": "bottom-[-25px] right-[-25px]",
  };

  return (
    <div
      className={`absolute rounded-full bg-azul-intenso opacity-10 z-0 ${sizeClasses[size]} ${positionClasses[position]}`}
    ></div>
  );
};

export default Bubble;
