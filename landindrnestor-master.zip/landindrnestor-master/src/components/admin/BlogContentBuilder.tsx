import React from "react";
import { FaImage, FaPlus, FaTrash } from "react-icons/fa";

// const [contentBlock, setContentBlocks] = React.useState<BlogContentBlock[]>([])

// Create first each block

type BlockType = "title" | "subtitle" | "paragraph" | "image";

type BlogContentBlock =
  | { id: string; type: "title" | "subtitle" | "paragraph"; value: string }
  | { id: string; type: "image"; value: string };

interface BlogContentBuilderProps {
  value?: BlogContentBlock[];
  onChange: (block: BlogContentBlock[]) => void;
}

const BlogContentBuilder: React.FC<BlogContentBuilderProps> = ({
  onChange,
  value,
}) => {
  const [blocks, setBlocks] = React.useState<BlogContentBlock[]>([]);
  const [newBlockType, setNewBlockType] =
    React.useState<BlockType>("paragraph");

  React.useEffect(() => {
    if (value && Array.isArray(value)) {
      setBlocks(value);
    }
  }, [value]);

  const handleAddBlock = () => {
    const newBlock: BlogContentBlock = {
      id: crypto.randomUUID(),
      type: newBlockType,
      value: "",
    } as BlogContentBlock;
    const updated = [...blocks, newBlock];
    setBlocks(updated);
    onChange(updated);
  };

  const handleBlockChange = (id: string, value: string) => {
    const updated = blocks.map((block) =>
      block.id === id ? { ...block, value } : block
    );
    setBlocks(updated);
    onChange(updated);
  };

  const handleImageChange = (id: string, file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const imageUrl = reader.result as string;
      const updated = blocks.map((block) =>
        block.id === id ? { ...block, value: imageUrl } : block
      );
      setBlocks(updated);
      onChange(updated);
    };
    reader.readAsDataURL(file);
  };

  const handleDeleteBlock = (id: string) => {
    const updated = blocks.filter((block) => block.id !== id);
    setBlocks(updated);
    onChange(updated);
  };

  return (
    <div className="space-y-4 mt-8">
      <h3 className="text-xl font-semibold text-gray-400">
        {" "}
        Contenido del blog
      </h3>

      {/* Agregar nuevo bloque*/}
      <div className="flex gap-4 items-center">
        <select
          value={newBlockType}
          onChange={(e) => setNewBlockType(e.target.value as BlockType)}
          className="px-3 py-2 border boder-gray300 rounded-lg"
        >
          <option value="title">Titulo</option>
          <option value="subtitle">Subtitulo</option>
          <option value="paragraph">Contenido</option>
          <option value="image">Imagen</option>
        </select>
        <button
          type="button"
          onClick={handleAddBlock}
          className="inline-flex items-center gap-2 bg-amber-300 text-white px-4 py-2 rounded-lg hover:bg-amber-600 transition-all"
        >
          <FaPlus />
          Agregar Bloque
        </button>
      </div>

      {/* Renderizar bloques */}
      {blocks.map((block) => (
        <div
          key={block.id}
          className="relative border rounded-lg p-4 bg-gray-50"
        >
          {/*Boton de eliminar */}
          <button
            type="button"
            onClick={() => handleDeleteBlock(block.id)}
            className="absolute top-2 right-2 text-red-500 hover:text-read-700"
          >
            <FaTrash />
          </button>
          {block.type === "title" && (
            <input
              type="text"
              placeholder="Titulo"
              value={block.value}
              onChange={(e) => handleBlockChange(block.id, e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg"
            />
          )}
          {block.type === "subtitle" && (
            <input
              type="text"
              placeholder="Subtitulo"
              value={block.value}
              onChange={(e) => handleBlockChange(block.id, e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg"
            />
          )}
          {block.type === "paragraph" && (
            <textarea
              placeholder="Contenido del parrafo"
              value={block.value}
              onChange={(e) => handleBlockChange(block.id, e.target.value)}
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg resize-none"
            />
          )}
          {block.type === "image" && (
            <div className="flex flex-col gap-3">
              {block.value ? (
                <img
                  src={block.value}
                  alt="Imagen del bloque"
                  className="w-full h-48 object-cover, rounded-md"
                />
              ) : (
                <div className="h-48 bg-gray-200 flex items-center justify-center rounded-md">
                  <FaImage className="text-gray-400 w-10 h-10" />
                </div>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  if (e.target.files?.[0]) {
                    handleImageChange(block.id, e.target.files[0]);
                  }
                }}
              />
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default BlogContentBuilder;
