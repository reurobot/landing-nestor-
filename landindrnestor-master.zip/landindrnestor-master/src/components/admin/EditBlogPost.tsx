// src/components/admin/EditBlogPost.tsx
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { useFetchBlogPost } from "../../firebase/useFetchBlogPost";
import BlogContentBuilder from "./BlogContentBuilder";
import { useEditBlogPost } from "../../firebase/useSaveBlogPost";
import type { BlogPost, BlogContentBlock } from "../../types/blog";
import { FaImage, FaSave } from "react-icons/fa";

const EditBlogPost = () => {
  const { id } = useParams<{ id: string }>();
  const { post, loading, error } = useFetchBlogPost(id);
  const { editBlogPost } = useEditBlogPost();

  const [formData, setFormData] = useState<BlogPost | null>(null);
  const [contentBlocks, setContentBlocks] = useState<BlogContentBlock[]>([]);
  const [previewImage, setPreviewImage] = useState<string>("");

  useEffect(() => {
    if (post) {
      setFormData(post);
      setContentBlocks(post.content || []);
      setPreviewImage(post.image);
    }
  }, [post]);

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => (prev ? { ...prev, [name]: value } : null));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageUrl = reader.result as string;
        setPreviewImage(imageUrl);
        setFormData((prev) => (prev ? { ...prev, image: imageUrl } : null));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData) return;

    const fullData: BlogPost = {
      ...formData,
      content: contentBlocks,
      id: id,
    };

    const result = await editBlogPost(fullData);
    if (result.success) {
      alert("Post actualizado correctamente");
    } else {
      alert("Hubo un error al guardar los cambios.");
    }
  };

  const categories = [
    "Neurología",
    "Respiratorio",
    "Tecnología",
    "Rehabilitación",
    "Medicina Física",
    "Traumatología",
  ];

  if (loading) return <p>Cargando...</p>;
  if (error) return <p>{error}</p>;
  if (!formData) return <p>No se encontró el post.</p>;

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-3xl font-bold text-[#1A2F6C] mb-6">
        Editar Entrada del Blog
      </h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Imagen */}
          <div className="col-span-full">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Imagen del Post
            </label>
            <div className="flex items-center space-x-4">
              <div className="relative w-full h-48 bg-gray-100 rounded-lg overflow-hidden">
                {previewImage ? (
                  <img
                    src={previewImage}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <FaImage className="w-12 h-12 text-gray-400" />
                  </div>
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="bg-[#6CC3C9] text-white px-4 py-2 rounded-lg cursor-pointer hover:bg-[#5AB1B7] transition-colors"
              >
                Seleccionar Imagen
              </label>
            </div>
          </div>

          {/* Título */}
          <div className="col-span-full">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Título
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#6CC3C9] focus:border-transparent"
              required
            />
          </div>

          {/* Categoría */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Categoría
            </label>
            <select
              name="category"
              value={formData.category}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#6CC3C9] focus:border-transparent"
              required
            >
              <option value="">Seleccionar categoría</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Fecha */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Fecha
            </label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#6CC3C9] focus:border-transparent"
              required
            />
          </div>

          {/* Extracto */}
          <div className="col-span-full">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Extracto
            </label>
            <textarea
              name="excerpt"
              value={formData.excerpt}
              onChange={handleInputChange}
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#6CC3C9] focus:border-transparent resize-none"
              required
            />
          </div>
        </div>
        {/* Contenido del blog */}
        <BlogContentBuilder value={contentBlocks} onChange={setContentBlocks} />
        {/* Botón de guardar */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="inline-flex items-center gap-2 bg-[#1A2F6C] text-white px-6 py-3 rounded-lg hover:bg-[#6CC3C9] transition-all duration-300"
          >
            <FaSave />
            Guardar Entrada
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditBlogPost;
