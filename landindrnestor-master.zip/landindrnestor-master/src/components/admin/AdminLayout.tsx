import { Outlet } from "react-router-dom";
import AdminSidebar from "./AdminSidebar";

const AdminLayout = () => {
  return (
    <div className="felx flex-col h-screen">
      <div className="flex flex-1 overflow-hidden">
        <AdminSidebar />
        <main className="flex-1 p6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
