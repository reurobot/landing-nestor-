import { Link } from "react-router-dom";

const AdminSidebar = () => {
  return (
    <aside className="w-64 min-w-[16rem] border-r bg-white felx flex-col">
      <nav className="flex-1 overflow-y-auto p-4 space-y-6">
        <div>
          <Link
            to={"/admin"}
            className="text-xs font-semibold text-gray-500 uppercase mb-2"
          >
            Editar Publicaciones
          </Link>
        </div>
        <div>
          <Link
            to={"/admin/blogform"}
            className="text-xs font-semibold text-gray-500 uppercase mb-2"
          >
            Crear publicacion
          </Link>
        </div>
      </nav>
    </aside>
  );
};

export default AdminSidebar;
