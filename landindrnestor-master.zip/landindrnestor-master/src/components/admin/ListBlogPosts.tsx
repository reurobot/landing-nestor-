import { FaCalendarAlt, FaUser, FaArrowRight } from "react-icons/fa";
import { Link } from "react-router-dom";
import { useFetchAllBlogPosts } from "../../firebase/useFetchBlogPost";

const ListBlogPosts = () => {
  const { posts, loading, error } = useFetchAllBlogPosts();
  if (loading) return <p> Cargando Publicaciones </p>;
  if (error) return <p> {error} </p>;
  if (!posts) return <p>Hubo un error al encontrar las publicaciones</p>;

  return (
    <section
      id="blog"
      className="py-20 bg-gradient-to-br from-gray-50 to-white"
    >
      <div className="max-w-7xl mx-auto px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => (
            <article
              key={post.id}
              className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-400 transform hover:-translate-y-2 overflow-hidden group"
            >
              <div className="relative overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-48 object-cover transition-transform duration-400 group-hover:scale-110"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-[#6CC3C9] text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {post.category}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                  <div className="flex items-center gap-1">
                    <FaCalendarAlt />
                    <span>{post.date}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <FaUser />
                    <span>{post.author}</span>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-[#1A2F6C] mb-3 line-clamp-2 group-hover:text-[#6CC3C9] transition-colors duration-300">
                  {post.title}
                </h3>

                <p className="text-gray-600 mb-4 line-clamp-3">
                  {post.excerpt}
                </p>

                <Link
                  to={`/admin/blog/${post.id}`}
                  className="inline-flex items-center gap-2 text-[#92C14F] font-semibold hover:text-[#6CC3C9] transition-colors duration-300 group/link"
                >
                  Editar
                  <FaArrowRight className="transition-transform duration-300 group-hover/link:translate-x-1" />
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ListBlogPosts;
