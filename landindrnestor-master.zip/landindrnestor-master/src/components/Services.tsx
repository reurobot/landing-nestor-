import {
  FaBrain,
  FaBone,
  FaProcedures,
  FaCheck,
  FaClipboardList,
} from "react-icons/fa";

const Services = () => {
  const services = [
    {
      icon: <FaBrain className="text-5xl text-azul-intenso mb-6" />,
      title: "Rehabilitación Neurológica",
      description:
        "Programas integrales para pacientes con condiciones neurológicas como:",
      items: [
        "Accidente Cerebrovascular (ACV)",
        "Lesión Medular",
        "Enfermedad de Parkinson",
        "Esclerosis Múltiple",
      ],
    },
    {
      icon: <FaBone className="text-5xl text-azul-intenso mb-6" />,
      title: "Manejo del Dolor Musculoesquelético",
      description: "Enfoque multidisciplinario para el tratamiento de:",
      items: [
        "Dolor lumbar crónico",
        "Artrosis y artritis",
        "Fibromialgia",
        "Lesiones deportivas",
      ],
    },
    {
      icon: <FaProcedures className="text-5xl text-azul-intenso mb-6" />,
      title: "Rehabilitación Postquirúrgica",
      description: "Protocolos de recuperación para:",
      items: [
        "Reemplazos articulares",
        "Cirugías de columna",
        "Reconstrucciones ligamentarias",
        "Amputaciones",
      ],
    },
  ];

  return (
    <section id="servicios" className="py-20 px-8 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-azul-oscuro mb-4 font-montserrat">
            Programas Especializados
          </h2>
          <p className="text-lg text-gris-texto max-w-3xl mx-auto">
            Tratamientos integrales adaptados a cada necesidad
          </p>
          <div className="w-20 h-1 bg-verde-lineas mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className={`bg-white rounded-xl p-8 shadow-lg transition-all duration-400 hover:-translate-y-2 hover:shadow-xl border-t-4 border-verde-claro relative overflow-hidden group animate-fade-in-up ${
                index === 1
                  ? "animation-delay-200"
                  : index === 2
                  ? "animation-delay-400"
                  : ""
              }`}
            >
              <div className="relative z-10">
                {service.icon}
                <h3 className="text-2xl font-bold text-[#000080] mb-4">
                  {service.title}
                </h3>
                <p className="text-gris-texto mb-4">{service.description}</p>
                <ul className="mt-4 space-y-3">
                  {service.items.map((item, i) => (
                    <li key={i} className="flex items-start">
                      <FaCheck className="text-verde-claro mt-1 mr-3 flex-shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="absolute inset-0 bg-verde-azulado-claro opacity-0 group-hover:opacity-100 transition-opacity duration-400 z-0"></div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16 animate-fade-in-up animation-delay-600">
          <a
            href="#contacto"
            className="cta-button text-white px-10 py-4 rounded-full font-bold inline-flex items-center gap-3 transition-all duration-400 hover:-translate-y-1 shadow-lg hover:shadow-xl"
            style={{
              backgroundColor: "#2e4194",
              boxShadow: "0 4px 6px -1px rgba(46, 65, 148, 0.3)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.boxShadow =
                "0 20px 25px -5px rgba(46, 65, 148, 0.4)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow =
                "0 4px 6px -1px rgba(46, 65, 148, 0.3)";
            }}
          >
            <FaClipboardList /> Solicitar evaluación personalizada
          </a>
        </div>
      </div>
    </section>
  );
};

export default Services;
