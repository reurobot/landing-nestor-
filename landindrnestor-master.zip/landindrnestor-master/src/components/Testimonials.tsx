import { FaStar, FaQuoteLeft } from "react-icons/fa";

const Testimonials = () => {
  const testimonials = [
    {
      name: "María González",
      condition: "Rehabilitación post-ACV",
      text: "Gracias al Dr. Borjas recuperé mi independencia. Su enfoque integral y profesionalismo marcaron la diferencia en mi recuperación.",
      rating: 5,
    },
    {
      name: "Carlos Rodríguez",
      condition: "Lesión medular",
      text: "El programa de rehabilitación superó mis expectativas. Hoy puedo realizar actividades que pensé nunca volvería a hacer.",
      rating: 5,
    },
    {
      name: "Ana Martínez",
      condition: "Fibromialgia",
      text: "Por fin encontré un tratamiento efectivo para mi dolor crónico. El Dr. Borjas realmente entiende las necesidades de sus pacientes.",
      rating: 5,
    },
  ];

  return (
    <section id="testimonios" className="py-20 px-8 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-azul-oscuro mb-4 font-montserrat">
            Testimonios de Pacientes
          </h2>
          <p className="text-lg text-gris-texto max-w-3xl mx-auto">
            Historias reales de transformación y recuperación
          </p>
          <div className="w-20 h-1 bg-verde-lineas mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className={`bg-white rounded-lg p-8 shadow-lg transition-all duration-400 hover:-translate-y-2 hover:shadow-xl relative animate-fade-in-up ${
                index === 1
                  ? "animation-delay-200"
                  : index === 2
                  ? "animation-delay-400"
                  : ""
              }`}
            >
              <FaQuoteLeft className="text-3xl text-verde-azulado mb-4 opacity-50" />

              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <FaStar key={i} className="text-yellow-400 text-lg" />
                ))}
              </div>

              <p className="text-gris-texto mb-6 italic leading-relaxed">
                "{testimonial.text}"
              </p>

              <div className="border-t pt-4">
                <h4 className="font-bold text-azul-oscuro">
                  {testimonial.name}
                </h4>
                <p className="text-sm text-gris-texto">
                  {testimonial.condition}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
