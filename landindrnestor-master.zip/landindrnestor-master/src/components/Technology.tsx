import {
  FaMicroscope,
  FaRobot,
  FaHeartbeat,
  FaLightbulb,
} from "react-icons/fa";

const Technology = () => {
  const technologies = [
    {
      icon: <FaMicroscope className="text-4xl text-[#92c14f] mb-4" />,
      title: "Diagnóstico Avanzado",
      description: "Estudios especializados para evaluación precisa",
    },
    {
      icon: <FaRobot className="text-4xl text-gray-600 mb-4" />,
      title: "Tecnología de Vanguardia",
      description: "Equipos de última generación para rehabilitación",
    },
    {
      icon: <FaHeartbeat className="text-4xl text-red-600 mb-4" />,
      title: "Monitoreo Continuo",
      description: "Seguimiento personalizado del progreso",
    },
    {
      icon: <FaLightbulb className="text-4xl text-yellow-400 mb-4" />,
      title: "Innovación Constante",
      description: "Actualización continua en técnicas y equipos",
    },
  ];

  return (
    <section id="tecnologia" className="py-20 px-8 bg-azul-oscuro">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-black mb-4 font-montserrat">
            Tecnología de Vanguardia
          </h2>
          <p className="text-lg text-gris-claro max-w-3xl mx-auto">
            Equipos y técnicas de última generación para mejores resultados
          </p>
          <div className="w-20 h-1 bg-verde-claro mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {technologies.map((tech, index) => (
            <div
              key={index}
              className={`text-center p-6 bg-white/10 rounded-lg backdrop-blur-sm transition-all duration-400 hover:-translate-y-2 hover:bg-white/20 animate-fade-in-up ${
                index === 1
                  ? "animation-delay-200"
                  : index === 2
                  ? "animation-delay-400"
                  : index === 3
                  ? "animation-delay-600"
                  : ""
              }`}
            >
              <div className="text-center mb-4">{tech.icon}</div>
              <h3 className="text-xl font-bold text-black mb-3">
                {tech.title}
              </h3>
              <p className="text-gris-claro text-sm">{tech.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Technology;
