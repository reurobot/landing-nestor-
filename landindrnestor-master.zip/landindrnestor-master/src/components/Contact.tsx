import {
  FaPhone,
  FaEnvelope,
  FaMapMarkerAlt,
  FaClock,
  FaPaperPlane,
} from "react-icons/fa";

const Contact = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Aquí puedes agregar la lógica para enviar el formulario
    console.log("Formulario enviado");
  };

  return (
    <section id="contacto" className="py-20 px-8 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-azul-oscuro mb-4 font-montserrat">
            Contacto
          </h2>
          <p className="text-lg text-gris-texto max-w-3xl mx-auto">
            Agenda tu consulta y comienza tu camino hacia la recuperación
          </p>
          <div className="w-20 h-1 bg-verde-lineas mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Información de contacto */}
          <div className="animate-fade-in-up">
            <h3 className="text-2xl font-bold text-azul-oscuro mb-8">
              Información de Contacto
            </h3>

            <div className="space-y-6">
              <div className="flex items-start">
                <FaPhone className="text-verde-claro text-xl mt-1 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-azul-oscuro">Teléfono</h4>
                  <p className="text-gris-texto">+52 (55) 1234-5678</p>
                  <p className="text-gris-texto">+52 (55) 8765-4321</p>
                </div>
              </div>

              <div className="flex items-start">
                <FaEnvelope className="text-verde-claro text-xl mt-1 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-azul-oscuro">Email</h4>
                  <p className="text-gris-texto">consultas@drborjas.com</p>
                  <p className="text-gris-texto">citas@drborjas.com</p>
                </div>
              </div>

              <div className="flex items-start">
                <FaMapMarkerAlt className="text-verde-claro text-xl mt-1 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-azul-oscuro">Dirección</h4>
                  <p className="text-gris-texto">
                    Av. Insurgentes Sur 1234
                    <br />
                    Col. Del Valle, CDMX
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <FaClock className="text-verde-claro text-xl mt-1 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-azul-oscuro">Horarios</h4>
                  <p className="text-gris-texto">
                    Lunes a Viernes: 8:00 - 18:00
                  </p>
                  <p className="text-gris-texto">Sábados: 9:00 - 14:00</p>
                </div>
              </div>
            </div>
          </div>

          {/* Formulario */}
          <div className="animate-fade-in-up animation-delay-200">
            <h3 className="text-2xl font-bold text-azul-oscuro mb-8">
              Envía un Mensaje
            </h3>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-azul-oscuro font-semibold mb-2">
                    Nombre
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-verde-claro focus:border-transparent transition-all"
                    required
                  />
                </div>
                <div>
                  <label className="block text-azul-oscuro font-semibold mb-2">
                    Teléfono
                  </label>
                  <input
                    type="tel"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-verde-claro focus:border-transparent transition-all"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-azul-oscuro font-semibold mb-2">
                  Email
                </label>
                <input
                  type="email"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-verde-claro focus:border-transparent transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-azul-oscuro font-semibold mb-2">
                  Mensaje
                </label>
                <textarea
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-verde-claro focus:border-transparent transition-all resize-none"
                  placeholder="Describe brevemente tu consulta o condición..."
                  required
                ></textarea>
              </div>

              <button
                type="submit"
                className="cta-button bg-verde-claro text-black px-8 py-4 rounded-full font-bold inline-flex items-center gap-3 transition-all duration-400 hover:-translate-y-1 shadow-lg shadow-verde-claro/30 hover:shadow-xl hover:shadow-verde-claro/40"
              >
                <FaPaperPlane /> Enviar Mensaje
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
