# Copilot Instructions

<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

## Project Overview

This is a modern web application built with:

- **Vite** - Fast build tool and development server
- **React** - UI library for building user interfaces
- **TypeScript** - Type-safe JavaScript with static type checking
- **Tailwind CSS** - Utility-first CSS framework

## Development Guidelines

- Use TypeScript for all components and utilities
- Follow React best practices and hooks patterns
- Use Tailwind CSS classes for styling instead of custom CSS
- Prefer functional components over class components
- Use proper TypeScript types and interfaces
- Follow modern ES6+ syntax and patterns

## Tailwind CSS Setup

This project uses the official Tailwind CSS Vite plugin (`@tailwindcss/vite`) for optimal performance and integration.
